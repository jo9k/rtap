function [jvx_handle, jvx_out_frame] =jvxProcessOffline_local(jvx_handle, jvx_in_frame)
    
% Obtain processing handle
global inProcessing;

% Check if miro and HRIRdata exist in path
if ~exist('miro.m') || ~exist('HRIR_FULL2DEG.mat')
    fprintf('failed.\n\n');
    error('The required files are not accessible.');
end
%-------------- set HRIR database ----------------

%%figure 
%%HRIR_FULL2DEG.plotQuadrature()  
% HRIR_FULL2DEG = HRIR_FULL2DEG.setDEG(); 
% Separate input signals
signal = jvx_in_frame(1,:);
%processing

%%GETPROPERTIES()
az = inProcessing.algo.AZ;
el = inProcessing.algo.EL;
r  = inProcessing.algo.R;

%%GETCLOSESTIR()
[irID, azFound, elFound] = inProcessing.algo.HRTFs.HRIR_FULL2DEG.closestIr(az,el);
closestIR = inProcessing.algo.HRTFs.HRIR_FULL2DEG.getIR(irID);
leftIR  = closestIR(:,1)';
rightIR = closestIR(:,2)';

%CONVOLUTION + OVERLAP SAVE
%left
NFFT = 1151;
A = fft(leftIR, NFFT);
B = fft(signal, NFFT);
AB = A.*B;
res_left = ifft(AB);  %1024+127
%Apply Window!
hammingW = hamming(NFFT)';
res_left = res_left.*hammingW;
%Process!
leftbuffer = inProcessing.algo.leftbuffercut;   %buffer from last frame
leftbuffer(1,1024) = 0; %zero padded
LEFT=leftbuffer+res_left(1,1:1024); %added cut buffer from last frame
inProcessing.algo.leftbuffercut = res_left(1,1025:(1024+127));  %save buffer from this frame
%right
NFFT = 1151;
A = fft(rightIR, NFFT);
B = fft(signal, NFFT);
AB = A.*B;
res_right = ifft(AB);  %1024+127
%Apply Window!
hammingW = hamming(NFFT)';
res_right = res_right.*hammingW;
%Process!
rightbuffer = inProcessing.algo.rightbuffercut;   %buffer from last frame
rightbuffer(1,1024) = 0; %zero padded
RIGHT=rightbuffer+res_right(1,1:1024); %added cut buffer from last frame
inProcessing.algo.rightbuffercut = res_right(1,1025:(1024+127));  %save buffer from this frame

%CALCULATE VOLUME in 1-100 range
if(inProcessing.algo.R < 1)
    inProcessing.algo.R = 1;
end
if(inProcessing.algo.R > 100)
    inProcessing.algo.R = 100;
end
r=inProcessing.algo.R*0.01;

% %%CIRCULATING AZ/EL - just for testing
% if(inProcessing.algo.num==100)
%     inProcessing.algo.AZ=mod(inProcessing.algo.AZ+5,360);
%     inProcessing.algo.EL= mod(inProcessing.algo.EL+15,360);
%     inProcessing.algo.R= mod(inProcessing.algo.R-1,100);
%     inProcessing.algo.num = 0;
% else
% inProcessing.algo.num=inProcessing.algo.num+1;
% end;

%%output
jvx_out_frame = [r*LEFT; r*RIGHT];

